# Sprint 2 - Texturing

Date: June 16, 2026  
Status: Completed  
Assignment Focus: Apply visual details, colors, and materials to game objects.

## Work Completed

- Added sprite textures for the snake, snake head, snake body, snake tail, and curved snake pieces.
- Added fruit/bonus sprites including apple, banana, cherry, and orange.
- Added board and empty tile graphics for the playable environment.
- Added game icon and supporting visual assets.

## Deliverables

- `Graphics/*.png`
- `Graphics/*.png.meta`

## Suggested Commit Message

`Sprint 2 - Texturing: Snake and food sprites added`
