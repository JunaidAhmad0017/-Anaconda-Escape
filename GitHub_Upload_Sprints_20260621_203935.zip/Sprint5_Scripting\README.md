# Sprint 5 - Scripting

Date: June 18, 2026  
Status: Completed  
Assignment Focus: Implement game logic, controls, interactions, and UI behavior.

## Work Completed

- Added board logic for tile management and gameplay space.
- Added snake movement and growth behavior.
- Added player input controller logic.
- Added game state, scoring, menu, game panel, game over panel, and sound management scripts.
- Included utility scripts used by the gameplay systems.

## Deliverables

- `Scripts/*.cs`
- `Scripts/Utils/*.cs`
- Unity script `.meta` files

## Suggested Commit Message

`Sprint 5 - Scripting: Gameplay scripts completed`
