# Sprint 4 - Level Design

Date: June 18, 2026  
Status: Completed  
Assignment Focus: Build the playable game environment.

## Work Completed

- Prepared the `Main` Unity scene for the Snake game.
- Used the tile prefab as the base environment component.
- Set up the scene file that contains the playable board and game layout.

## Deliverables

- `Scenes/Main.unity`
- `Scenes/Main.unity.meta`
- `Prefabs/Tile.prefab`
- `Prefabs/Tile.prefab.meta`

## Suggested Commit Message

`Sprint 4 - Level Design: Main game scene configured`
