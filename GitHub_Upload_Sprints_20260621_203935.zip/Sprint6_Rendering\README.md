# Sprint 6 - Rendering

Date: June 19, 2026  
Status: Completed  
Assignment Focus: Final output, visual settings, and presentation.

## Work Completed

- Added the project screenshot as final visual output.
- Included Unity graphics and quality settings used by the project.
- Prepared final render evidence for assignment submission.

## Deliverables

- `Output/Screenshot.png`
- `ProjectSettings/GraphicsSettings.asset`
- `ProjectSettings/QualitySettings.asset`

## Suggested Commit Message

`Sprint 6 - Rendering: Final screenshot and render settings added`
